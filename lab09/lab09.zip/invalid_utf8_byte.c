// Given an UTF-8 string, return the index of the first invalid byte.
// If there are no invalid bytes, return -1.

// Do NOT change this function's return type or signature.
int invalid_utf8_byte(char *utf8_string) {
    
    // TODO: implement this function

    return 42;
}
